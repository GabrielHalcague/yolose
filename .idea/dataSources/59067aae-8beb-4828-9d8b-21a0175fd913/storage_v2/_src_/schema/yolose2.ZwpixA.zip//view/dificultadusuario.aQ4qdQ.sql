create definer = root@localhost view dificultadusuario as
select `h`.`idUs` AS `idUs`, sum(`h`.`estado` = 0) / count(0) AS `dificultad`
from `yolose2`.`historialpartidas` `h`
group by `h`.`idUs`;

