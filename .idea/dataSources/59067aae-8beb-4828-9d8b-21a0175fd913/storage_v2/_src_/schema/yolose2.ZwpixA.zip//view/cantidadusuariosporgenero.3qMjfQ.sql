create definer = root@localhost view cantidadusuariosporgenero as
select case
           when `u`.`generoId` = 1 then 'Masculino'
           when `u`.`generoId` = 2 then 'Femenino'
           else 'No Especificado' end AS `sexo`,
       count(0)                       AS `cantidad`
from `yolose2`.`usuario` `u`
group by `u`.`generoId`;

