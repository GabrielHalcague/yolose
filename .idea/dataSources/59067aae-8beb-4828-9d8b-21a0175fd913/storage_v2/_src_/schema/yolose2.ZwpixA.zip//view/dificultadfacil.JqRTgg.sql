create definer = root@localhost view dificultadfacil as
select `p`.`id` AS `preguntaID`, `p`.`preg` AS `pregunta`, `prc`.`idResp` AS `respuestaCorrecta`, `c`.`color` AS `color`
from (((`yolose2`.`pregunta` `p` join `yolose2`.`categoria` `c`
        on (`p`.`idCat` = `c`.`id`)) join `yolose2`.`pregunta_respuesta_correcta` `prc`
       on (`p`.`id` = `prc`.`idPreg`)) join `yolose2`.`estado` `e` on (`p`.`idEst` = `e`.`id`))
where `p`.`resCor` / `p`.`pregTot` between 0 and 0.3
  and `e`.`descr` like 'ACTIVO';

