create definer = root@localhost view ranking as
select `u`.`nombreUsuario` AS `nombreUsuario`, sum(`hp`.`estado` = 1) AS `puntaje`
from (`yolose2`.`historialpartidas` `hp` join `yolose2`.`usuario` `u` on (`hp`.`idUs` = `u`.`id`))
group by `hp`.`idUs`
order by sum(`hp`.`estado` = 1) desc;

